<? 
session_start();
if(isset($_REQUEST['user'])&&(isset($_REQUEST['pwd']))){
$usuario=$_POST['user'];
$clave=$_POST['pwd'];
  }
$clave_crypt="";
$nfilas=0;
if( isset($usuario) && isset($clave)){
include 'conf/conexion.php';
$salt=substr($usuario,0,2);
$salt=strtoupper($salt);
$clave_crypt=crypt($clave,$salt);
$sql="SELECT nombre,clave,perfil,correo
 FROM tbl_usuario
 WHERE correo = '$usuario' 
  AND clave = '$clave_crypt'";
$consulta=mysqli_query($con,$sql);
$nfilas=mysqli_num_rows($consulta);
while($reg=mysqli_fetch_array($consulta)){
   $_SESSION["usuario_valido"]=$reg['correo'];
  $_SESSION["nombre"]=$reg['nombre'];
     $_SESSION["perfil"]=$reg['perfil'];
 }// fin while
mysqli_close($con);
}// fin si hay usuario y clave
if($nfilas>0){
   $usuario_valido=$usuario; 
   $_SESSION['usuario_valido']=$usuario_valido;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Inicio</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r125/three.min.js"></script>
  <link href="ss/sty.css" rel="stylesheet">
 
  <script src="js/main.js"></script>
<script type="x-shader/x-vertex" id="vertexshader">

  attribute float size;
  attribute vec3 customColor;
  varying vec3 vColor;

  void main() {

    vColor = customColor;
    vec4 mvPosition = modelViewMatrix * vec4( position, 1.0 );
    gl_PointSize = size * ( 300.0 / -mvPosition.z );
    gl_Position = projectionMatrix * mvPosition;

  }

</script>
<script type="x-shader/x-fragment" id="fragmentshader">

 uniform vec3 color;
 uniform sampler2D pointTexture;

 varying vec3 vColor;

 void main() {

   gl_FragColor = vec4( color * vColor, 1.0 );
   gl_FragColor = gl_FragColor * texture2D( pointTexture, gl_PointCoord );

 }
</script>
  </head>
  <body>
  
    
    <? if(isset($_SESSION['usuario_valido']) ){
         if(isset($_SESSION['usuario_valido']) &&($_SESSION['perfil'])=='1'){
           include 'MenuAdmin.php';
         }
         if(isset($_SESSION['usuario_valido']) &&($_SESSION['perfil'])=='0'){
             include 'Menu.php';
         }
         /*si no a iniciado session*/
        }else{
        include'presentacion.php';
       }      

  ?>
     
  
</body>
</html>
