<!doctype html>
<html lang="en">
<head>
  <title>HAPPY GUMMIES</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="ss/styles.css" rel="stylesheet">
</head>
<body>
  <div class="login-box">
    <h2>Registrar</h2>
    <form method="post" action="Generar_pwr.php">
      <div class="user-box">
        <input type="nombre" placeholder="" name="nombre" id="nombre" required >
        <label>Nombre</label>
      </div>
      <div class="user-box">
        <input type="email" id="correo"
 placeholder="" name="correo"  required>
        <label>Correo</label>
      </div>
      <div class="user-box">
        <input type="tel"  id="tel"
 placeholder="" name="tel" required>
        <label>Telefono</label>
      </div>
      <div class="user-box">
        <input type="password"  id="pwd"
 placeholder="" name="pwd" required>
        <label>Contraseña</label>
      </div>
      <div class="user-box">
        <input type="password"  id="rpwd"
 placeholder="" name="rpwd" required>
        <label>Re contraseña</label>
      </div>
      
       <a href="Acceso.php">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
        Volver
      </a>
      <a> <button type="submit" class="boton" value="GUARDAR"> Crear
         <span></span>
        <span></span>
        <span></span>
        <span></span>
         </button>
      </a>
    </form>
  </div>
</body>
</html>