<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Inicio</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r125/three.min.js"></script>
  <link href="ss/sty.css" rel="stylesheet">
</head>
 <body>

<div class="container-sm border">
<div class="form-group">

 <?
 $correo =$_POST['correo'];
 $usuario=$_POST['nombre'];
 $Telefono=$_POST['tel'];
 $clave=$_POST['pwd'];
 $estado= "Activo";
 $rclave=$_POST['rpwd'];
 $perfil=0;
$grado=0;
 /* echo '<br>'.$correo;
 echo '<br>'.$usuario;
 echo '<br>'.$clave;
 echo '<br>'.$rclave;*/
 if ($clave==$rclave){
 include 'conf/conexion.php';
 $instruccion = "SELECT * FROM tbl_usuario WHERE correo='$correo'";
 $consulta = mysqli_query ($con,$instruccion) or die ("Fallo en la consulta correo");
 //or die mysql_errno($consulta);
 // Mostrar resultados de la consulta
 $nfilas = mysqli_num_rows ($consulta);
 if ($nfilas == 0)
 {
 $salt = substr($correo, 0, 2);
   echo"salt".$salt;
 $salt=strtoupper($salt);
 $clave_crypt = crypt ($clave, $salt);
 $instruccion = "INSERT INTO tbl_usuario (cons,nombre,perfil,correo,telefono,estado,grado,clave) 
 values (null,'$usuario','$perfil','$correo','$Telefono','$estado','$grado','$clave_crypt')";
 $consulta = mysqli_query ($con,$instruccion ) or die ("Fallo en la inserción");
 mysqli_close ($con);

 
echo '<li class="nav-item"><a class="nav-link active" aria-current="page" href="hola.php"></a></li>';
 echo '<strong>Usuario: <br>'. $usuario. 'creado con éxito</strong> </div>';
   
 }else{
 echo '<center><div id="magic">';
 echo '<button type="button">×</button>';
 echo '<strong>Correo no válido</strong> </div></center>';
   
 } }else{
 echo '<div class="alert alert-danger alert-dismissible">';
 echo '<button type="button" class="close" data-dismiss="alert">×</button>';
 echo '<strong>Las claves no coinciden</strong> </div>';
 }
 echo "<meta http-equiv='refresh' content='2;url=index.php'/>";
?>
</div>
</div>
</body>
</html>