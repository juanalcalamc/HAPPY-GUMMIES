<?
//session_start();
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Menú</title>
   <link href="ss/style.css" rel="stylesheet">
<body>
 
  <ul>
    <li style="--clr:#00ade1">
      <? 
     echo '<li class="nav-item"><a class="nav-link active" aria-current="page" href="salir.php">salir</a></li>';
     
     ?>
    </li>
    
    <li style="--clr:#ffdd1c">
      <a href="Gomitas.php" data-text="&nbsp;Gomitas">&nbsp;Gomitas&nbsp;</a>
    </li>
    <li style="--clr:#00dc82">
      <a href="logros.php" data-text="&nbsp;Logros">&nbsp;Logros&nbsp;</a>
    </li>
    <li style="--clr:#dc00d4">
      <a href="Contacto.php" data-text="&nbsp;Contactanos">&nbsp;Contactanos&nbsp;</a>
    </li>
    <li style="--clr:#dc00d4">
      <a href="ss/manual.pdf" target="_blank" data-text="&nbsp;Manual">&nbsp;Manual&nbsp;</a>
    </li>
  </ul>
</body>
</html>