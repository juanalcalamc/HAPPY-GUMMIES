<!doctype html>
<html lang="en">
<head>
  <title>HAPPY GUMMIES</title>
  <link href="ss/styles.css" rel="stylesheet">
</head>
<body>
  <div class="login-box">
    <h2>Acceso</h2>
 <form action="ingresar.php" method="post" >
   <div class="user-box">
        <input type="email" name="user" required>
        <label>Usuario</label>
      </div>
      <div class="user-box">
        <input type="password" name="pwd" required>
        <label>Contraseña</label>
      </div>
  
      <a> <button type="submit" class="boton" value="Ingresar"> Entrar
         <span></span>
        <span></span>
        <span></span>
        <span></span>
         </button>
      </a>
       <a href="Registro.php">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
       Crear
      </a>
    </form>
  </div>
</body>
</html>
