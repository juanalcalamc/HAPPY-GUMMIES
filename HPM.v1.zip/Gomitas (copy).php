
<?

  include 'config/conexion.php';
    $instruccion = "SELECT cons,nombre,descripcion,val_unidad,val_paquete,img FROM tbl_productos WHERE estado=1";
    $consulta = mysqli_query ($con,$instruccion) or die ("Fallo en la consulta usuario");
    while($reg=mysqli_fetch_array($consulta)){
        $usuario=$reg['nombre'];
       $descripcion=$reg['descripcion'];
       $cons=$reg['cons'];
       $val_u=$reg['val_unidad'];
       $val_p=$reg['val_paquete'];
       $img=$reg['img'];
        $correo=$reg['correo'];
        $perfil=$reg['perfil'];
    
    }
    mysqli_close($con);
?>


<head>
   <link href="ss/styl.css" rel="stylesheet">
  
</head>
<ul class="cards">
  <li>
    <a href="" class="card">
      <img src="https://i.imgur.com/oYiTqum.jpg" class="card__image" alt="" />
      <div class="card__overlay">
        <div class="card__header">
          <svg class="card__arc" xmlns="http://www.w3.org/2000/svg"><path /></svg>                     
          <img class="card__thumb" src="https://i.imgur.com/7D7I6dI.png" alt="" />
          <div class="card__header-text">
            <h3 class="card__title">GOMITAS ENCHILADAS</h3>      
            <span class="card__status">Precios:</span>
          </div>
        </div>
        <p class="card__description">GOMITAS CUBIERTAS DE DELICIOSO CHILE TIPO CHAMOY. PICANTE ALTO Y BAJO.</p>
      </div>
    </a>      
  </li>
  <li>
    <a href="" class="card">
      <img src="https://i.imgur.com/2DhmtJ4.jpg" class="card__image" alt="" />
      <div class="card__overlay">        
        <div class="card__header">
          <svg class="card__arc" xmlns="http://www.w3.org/2000/svg"><path /></svg>                 
          <img class="card__thumb" src="https://i.imgur.com/sjLMNDM.png" alt="" />
          <div class="card__header-text">
            <h3 class="card__title">GOMITAS HAWAIIAN MANZANA</h3>
            <span class="card__status">Precio:</span>
          </div>
        </div>
        <p class="card__description">SUAVES Y DELICIOSAS GOMITAS CON FORMA Y SABOR MANZANA.</p>
      </div>
    </a>
  </li>
  <li>
    <a href="" class="card">
      <img src="https://i.imgur.com/oYiTqum.jpg" class="card__image" alt="" />
      <div class="card__overlay">
        <div class="card__header">
          <svg class="card__arc" xmlns="http://www.w3.org/2000/svg"><path /></svg>                     
          <img class="card__thumb" src="https://i.imgur.com/7D7I6dI.png" alt="" />
          <div class="card__header-text">
            <h3 class="card__title">GOMITAS DE FRUTA</h3>
            <span class="card__tagline">Precio:</span>           
          </div>
        </div>
        <p class="card__description">GOMITAS DE COLORES CON FIGURAS Y SABORES FRUTALES ESPOLVOREADAS CON AZÚCAR.</p>
      </div>
    </a>
  </li>
  <li>
    <a href="" class="card">
      <img src="https://i.imgur.com/2DhmtJ4.jpg" class="card__image" alt="" />
      <div class="card__overlay">
        <div class="card__header">
          <svg class="card__arc" xmlns="http://www.w3.org/2000/svg"><path /></svg>                 
          <img class="card__thumb" src="https://i.imgur.com/sjLMNDM.png" alt="" />
          <div class="card__header-text">
            <h3 class="card__title">GOMITAS EN FORMA DE POSTRES</h3>
            <span class="card__status">Precio:</span>
          </div>          
        </div>
        <p class="card__description">GOMITAS GRANDES Y CREMOSAS</p>
      </div>
    </a>
  </li>         
</ul>
<body>
  
<div id="magic">
      
    </div>
    <div class="playground">
      <div class="bottomPosition">
       <div class="content"><a href="Menu.php">
      <center><button>  <link href="ss/lis.css" rel="stylesheet"> Menú
      </button></center>
    </div>
      </div>
    </div>
</body>


