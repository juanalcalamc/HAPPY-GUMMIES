
<head>
   <link href="ss/styl.css" rel="stylesheet">
  
</head>
<ul class="cards">
  <li>
    <a href="" class="card">
      <img src="img/001.png" class="card__image" alt="" />
      <div class="card__overlay">
        <div class="card__header">
          <svg class="card__arc" xmlns="http://www.w3.org/2000/svg"><path /></svg>                     
          <img class="card__thumb" src="img/logo.png" alt="" />
          <div class="card__header-text">
            <h3 class="card__title">GOMITAS ENCHILADAS</h3>            
            <span class="card__status">Precios:</span>
          </div>
        </div>
        <p class="card__description">GOMITAS CUBIERTAS DE DELICIOSO CHILE TIPO CHAMOY. PICANTE ALTO Y BAJO.</p>
      </div>
    </a>      
  </li>
  <li>
    <a href="" class="card">
     <img src="img/02.jpg" class="card__image" alt="" />
      <div class="card__overlay">        
        <div class="card__header">
          <svg class="card__arc" xmlns="http://www.w3.org/2000/svg"><path /></svg>                 
          <img class="card__thumb" src="img/logo.png" alt="" />
          <div class="card__header-text">
            <h3 class="card__title">GOMITAS HAWAIIAN MANZANA</h3>
            <span class="card__status">Precio:</span>
          </div>
        </div>
        <p class="card__description">SUAVES Y DELICIOSAS GOMITAS CON FORMA Y SABOR MANZANA.</p>
      </div>
    </a>
  </li>
  <li>
    <a href="" class="card">
     <img src="img/03.jpg" class="card__image" alt="" />
      <div class="card__overlay">
        <div class="card__header">
          <svg class="card__arc" xmlns="http://www.w3.org/2000/svg"><path /></svg>                     
          <img class="card__thumb" src="img/logo.png" alt="" />
          <div class="card__header-text">
            <h3 class="card__title">GOMITAS DE FRESA</h3>
            <span class="card__tagline">Precio:</span>            
            
          </div>
        </div>
        <p class="card__description">GOMITAS DE COLORES CON FIGURAS Y SABORES FRUTALES ESPOLVOREADAS CON AZÚCAR.</p>
      </div>
    </a>
  </li>
  <li>
    <a href="" class="card">
     <img src="img/04.jpg" class="card__image" alt="" />
      <div class="card__overlay">        
        <div class="card__header">
          <svg class="card__arc" xmlns="http://www.w3.org/2000/svg"><path /></svg>                 
          <img class="card__thumb" src="img/logo.png" alt="" />
          <div class="card__header-text">
            <h3 class="card__title">GOMITAS DE UVA</h3>
            <span class="card__status">Precio:</span>
          </div>
        </div>
        <p class="card__description">GOMITAS DE COLORES CON FIGURAS Y SABORES FRUTALES ESPOLVOREADAS CON AZÚCAR.</p>
      </div>
    </a>
  </li>
  <li>
    <a href="" class="card">
      <img src="img/05.jpg" class="card__image" alt="" />
      <div class="card__overlay">        
        <div class="card__header">
          <svg class="card__arc" xmlns="http://www.w3.org/2000/svg"><path /></svg>                 
         <img class="card__thumb" src="img/logo.png" alt="" />
          <div class="card__header-text">
            <h3 class="card__title">GOMITAS DE MANDARINA</h3>
            <span class="card__status">Precio:</span>
          </div>
        </div>
        <p class="card__description">GOMITAS DE SABORES FRUTALES ESPOLVOREADAS CON DELICIOSO SAL LIMON.</p>
      </div>
    </a>
  </li>
  <li>
    <a href="" class="card">
     <img src="img/001.png" class="card__image" alt="" />
      <div class="card__overlay">
        <div class="card__header">
          <svg class="card__arc" xmlns="http://www.w3.org/2000/svg"><path /></svg>                     
          <img class="card__thumb" src="img/logo.png" alt="" />
          <div class="card__header-text">
            <h3 class="card__title">GOMITAS DE SANDIA</h3>
            <span class="card__tagline">Precio:</span>            
            
          </div>
        </div>
        <p class="card__description">GOMITAS DE COLORES CON FIGURAS Y SABORES FRUTALES ESPOLVOREADAS CON AZÚCAR.</p>
      </div>
    </a>
  </li>
  <li>
    <a href="" class="card">
      <img src="img/001.png" class="card__image" alt="" />
      <div class="card__overlay">        
        <div class="card__header">
          <svg class="card__arc" xmlns="http://www.w3.org/2000/svg"><path /></svg>                 
          <img class="card__thumb" src="img/logo.png" alt="" />
          <div class="card__header-text">
            <h3 class="card__title">GOMITAS DE CEREZA</h3>
            <span class="card__status">Precio:</span>
          </div>
        </div>
        <p class="card__description">GOMITAS DE COLORES CON FIGURAS Y SABORES FRUTALES ESPOLVOREADAS CON AZÚCAR.</p>
      </div>
    </a>
  </li>
  <li>
    <a href="" class="card">
     <img src="img/001.png" class="card__image" alt="" />
      <div class="card__overlay">
        <div class="card__header">
          <svg class="card__arc" xmlns="http://www.w3.org/2000/svg"><path /></svg>                     
          <img class="card__thumb" src="img/logo.png" alt="" />
          <div class="card__header-text">
            <h3 class="card__title">GOMITAS DE MANGO</h3>
            <span class="card__tagline">Precio:</span>            
            
          </div>
        </div>
        <p class="card__description">GOMITAS DE SABORES FRUTALES ESPOLVOREADAS CON DELICIOSO SAL LIMON.</p>
      </div>
    </a>
  </li>
  <li>
    <a href="" class="card">
      <img src="img/001.png" class="card__image" alt="" />
      <div class="card__overlay">
        <div class="card__header">
          <svg class="card__arc" xmlns="http://www.w3.org/2000/svg"><path /></svg>                 
          <img class="card__thumb" src="img/logo.png" alt="" />
          <div class="card__header-text">
            <h3 class="card__title">GOMITAS DE MORA DULCE</h3>
            <span class="card__status">Precio:</span>
          </div>          
        </div>
        <p class="card__description">GOMITAS DE COLORES CON FIGURAS Y SABORES FRUTALES ESPOLVOREADAS CON AZÚCAR.</p>
      </div>
    </a>
  </li>    
</ul>
<body>
  
<div id="magic">
      
    </div>
    <div class="playground">
      <div class="bottomPosition">
       <div class="content"><a href="Menu.php">
      <center><button>  <link href="ss/lis.css" rel="stylesheet"> Menú
      </button></center>
    </div>
      </div>
    </div>
</body>


