Listar todos los productos
