<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Inicio</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r125/three.min.js"></script>
  <link href="ss/sty.css" rel="stylesheet">
</head>
 <body>

<div class="container-sm border">
<div class="form-group">

 <?
 $nombre =$_POST['nombre'];
 $descripcion=$_POST['descripcion'];
 $val_unidad=$_POST['val_unidad'];
 $val_paquete=$_POST['val_paquete'];
 costo=$_POST['costo'];
 img=$_POST['img'];
$estado= "Activo";
 $cantidad=0;

 /* echo '<br>'.$correo;
 echo '<br>'.$usuario;
 echo '<br>'.$clave;
 echo '<br>'.$rclave;*/
 if ($clave==$rclave){
 include 'conf/conexion.php';
 
 
 $salt=strtoupper($salt);
 
 $instruccion = "INSERT INTO tbl_usuario (cons,nombre,perfil,correo,telefono,estado,grado,clave) 
 values (null,'$nombre','$descripcion','$val_unidad',' $val_paquete',' $costo','$img','$estado',' $cantidad')";
 $consulta = mysqli_query ($con,$instruccion ) or die ("Fallo en la inserción");
 mysqli_close ($con);

 echo '<div class="login-box>';
 echo '<button type="button" class="close" data-dismiss="alert">×</button>';
 echo '<strong>Usuario: <br>'. $usuario. 'creado con éxito</strong> </div>';
   
 }else{
 echo '<center><div id="magic">';
 echo '<button type="button">×</button>';
 echo '<strong>Correo no válido</strong> </div></center>';
   
 } }else{
 echo '<div class="alert alert-danger alert-dismissible">';
 echo '<button type="button" class="close" data-dismiss="alert">×</button>';
 echo '<strong>Las claves no coinciden</strong> </div>';
 }
 echo "<meta http-equiv='refresh' content='2;url=index.php'/>";
?>
</div>
</div>
</body>
</html>