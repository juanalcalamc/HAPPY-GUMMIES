    
    <div id="magic">
      
    </div>
    <div class="playground">
      <div class="bottomPosition">
       <div class="content"><a href="Acceso.php">
      <button> Acceso
      </button>
    </div>
      </div>
    </div>
   