<?
session_start();
$usuario=$_POST['user'];
$clave=$_POST['pwd'];
$clave_crypt="";
$nfilas=0;
if( isset($usuario) && isset($clave)){
include 'conf/conexion.php';
$salt=substr($usuario,0,2);
$salt=strtoupper($salt);
$clave_crypt=crypt($clave,$salt);
$sql="SELECT nombre,clave,perfil,correo
 FROM tbl_usuario
 WHERE correo = '$usuario' 
  AND clave = '$clave_crypt'";
$consulta=mysqli_query($con,$sql);
$nfilas=mysqli_num_rows($consulta);
while($reg=mysqli_fetch_array($consulta)){
   $_SESSION["usuario_valido"]=$reg['correo'];
  $_SESSION["nombre"]=$reg['nombre'];
     $_SESSION["perfil"]=$reg['perfil'];
 }// fin while
mysqli_close($con);
}// fin si hay usuario y clave
if($nfilas>0){
   $usuario_valido=$usuario; 
   $_SESSION['usuario_valido']=$usuario_valido;
}
?>
<!DOCTYPE html>
<html lang="en">
    <? include 'head.php'?>
    <body>
        <!-- Responsive navbar-->
        <?
//echo "usuario".$_SESSION[usuario_valido];
//echo "perfil". $_SESSION['perfil'];
        if(isset($_SESSION['usuario_valido']) &&($_SESSION['perfil'])=='1'){
        include 'MenuAdmin.php';
        }
        ?>
       
        <?
        if(isset($_SESSION['usuario_valido'])&&($_SESSION['perfil']=='0')){
          include 'Menu.php';
        }else{
         include 'Acceso.php';
        }
        ?>
         </div>
         </div>    
        </div>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>